# GameHub+

A static gaming and entertainment hub made for GitHub Pages.

## Publish it

1. Create a GitHub repository.
2. Upload `index.html` and `.nojekyll`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then click **Save**.
6. Open the website URL GitHub gives you.

The site is plain HTML, CSS, and JavaScript, so no build command is needed.
